export * from "./access-resolver";
